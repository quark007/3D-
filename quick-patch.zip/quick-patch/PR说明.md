## 这个 PR 做了什么
第 3 章遵义街景的观感和人物，加上王贵的模型和走动。改动都限定在**有街景模型的第 3 章**和**配置了 `roam`/`weathering` 的人物（目前只有王贵）**，其它章节和人物的行为不变。

| 方面 | 改动 |
|---|---|
| 街景氛围 | 渐变天空、地平线同色雾、环境光照，桌面端恢复阴影 |
| 街景相机 | 第三人称：距人物 7.6m（原 11.4m），走路时缓慢转到身后 |
| 去重复 | 石板、青砖、灰瓦、白灰墙、木板，按各自贴图结构处理 |
| 街市 | 12 个摊位、16 块招牌、热气、8 个行人、摊主 |
| 平民模型 | 挑夫 / 妇女 / 老掌柜，替换「军装换色」 |
| 王贵 | 走路动画、布料法线贴图、程序化皱纹胡茬泥渍、交谈表情；同章只有一个王贵，剧情推进时走到下一站位 |
| 体积 | `zunyi_street.glb` 12.5MB → 4.8MB |

## ⚠️ 测试状态
**这些改动都没有在浏览器里跑过**。作者（Quick）所在环境无法运行浏览器和本仓库，只做了：GLB 结构校验、括号配对检查、Python 模拟（寻路、去重复、骨骼重定向）。推送脚本在提交前用 `node --check` 做了第一次真正的语法检查。
`evidence/quick/` 里的图都是**模拟图，不是游戏截图**。

合并前请至少：
1. `node serve.cjs 8080`，打开 `march-world/preview.html?3d=1`，控制台粘贴 `tools/quick/test-ch3.js`，看「判定」全部为 true
2. 打开 `march-world/character-preview.html?char=wang-gui&renderer=webgl`，看做旧效果和 Walk 动画
3. 第 7 章粘贴 `tools/quick/test-wanggui-walk.js`
4. 每项可单独关闭排查：`localStorage.cz_zunyi_notile='0'`（去重复）、`localStorage.cz_weathering='0'`（做旧）

## 尚未完成
- `tools/quick/wang-gui-refine.py` 还没运行过：会给王贵加 browDown/browUp/smile 表情形态、调体型、生成 `wang-gui-lod.glb`。在此之前交谈表情没有效果、手机端加载远景版会 404 后回退完整版（控制台有一条提示）
- 平民模型共用士兵的头和脸；走路时衣摆有轻微穿模
- 王贵走动不避让其他人物；2D 回退模式下仍是静态站位

## 合并注意
- 基于 `main@f537df4`。与 `3D人物优化` 分支（落后 main 10 个提交）可能在 `actors3d.js` 冲突，建议该分支先 rebase 到合并后的 main
