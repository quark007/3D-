(() => {
  'use strict';
  const M = window.CZMarchWorld._;
  // 本脚本的地址，用来按相对路径加载做旧模块（index.html 与 preview.html 都能用）
  const SCRIPT_BASE = document.currentScript?.src || location.href;
  const paths = {
    commander: '/assets/models-v03/char_commander.glb',
    logistics: '/assets/models-v03/char_logistics.glb',
    soldier: '/assets/models-v03/char_soldier.glb',
    medic: '/assets/models-v03/char_medic.glb'
  };
  // 街市平民（挑夫 / 妇女 / 老掌柜）：沿用通用模型的骨骼和走路、待机、交谈动画，衣物重做。
  // 只在配置了 streetLife 的街景章节加载；加载失败时退回通用模型换色（FALLBACK_ROLE）
  const CIVILIAN_PATHS = {
    farmer: '/assets/characters/civilians/civ-farmer.glb',
    woman: '/assets/characters/civilians/civ-woman.glb',
    elder: '/assets/characters/civilians/civ-elder.glb'
  };
  const FALLBACK_ROLE = { farmer: 'logistics', woman: 'medic', elder: 'commander' };
  const CIVILIAN_HEIGHT = { farmer: [1.6, 1.72], woman: [1.5, 1.6], elder: [1.58, 1.66] };
  const DEFAULT_HEIGHT = 1.76;
  const CHARACTER_PROFILES = {
    he_wen: { glbUrl: '/assets/characters/he-wen/he-wen-web.glb', height: 1.78, scaleBias: 1, idle: 'Idle' },
    // lodUrl：手机端优先加载约 8000 面的远景版本，不存在时自动用完整版；weathering：做旧与面部年龄感（character-weathering.js）
    // roam：同一章只出现一个王贵，剧情推进时自己走到下一个站位，等人时在站位附近踱步（见下方「走动的剧情人物」）
    //   speed 平时步速 m/s，hurrySpeed 离下个站位还远时的步速，pace 踱步半径 m（0 关闭），paceAway 玩家离站位多远时才踱步
    wang_gui: { glbUrl: '/assets/characters/wang-gui/wang-gui-web.glb', lodUrl: '/assets/characters/wang-gui/wang-gui-lod.glb', height: 1.70, scaleBias: 1, idle: 'Idle', weathering: 'wang_gui',
      roam: { speed: 1.35, hurrySpeed: 2.5, pace: 2.4, paceAway: 9 } },
    chen_xiaoman: { height: 1.67 },
    medic_1: { height: 1.61 },
    logistics_1: { height: 1.73 },
    liaison_1: { height: 1.65 },
    boatman_1: { height: 1.74 },
    guide_1: { height: 1.68 },
    civilian_1: { height: 1.63 }
  };
  const headings = { e: 0, s: Math.PI / 2, w: Math.PI, n: -Math.PI / 2 };
  const npcKey = anchor => M.anchors.npcKey(anchor.anchorId, anchor.label);

  async function loadModel(T, GLTFLoader, draco, url, signal) {
    const response = await fetch(url, { signal });
    if (!response.ok) throw Error(`人物模型 ${url} HTTP ${response.status}`);
    const data = await response.arrayBuffer();
    if (signal?.aborted) throw new DOMException('Aborted', 'AbortError');
    const loader = new GLTFLoader().setDRACOLoader(draco);
    loader.register(parser => ({
      name: 'CZ_embedded_images',
      beforeRoot() {
        // Embedded images use img-src blob:, without widening connect-src for ImageBitmap fetches.
        parser.textureLoader = new T.TextureLoader(parser.options.manager);
      }
    }));
    return loader.parseAsync(data, url.slice(0, url.lastIndexOf('/') + 1));
  }

  function disposeModels(sources) {
    const resources = new Set();
    for (const source of sources) source.scene.traverse(node => {
      if (node.isSkinnedMesh) resources.add(node.skeleton);
      if (node.geometry) resources.add(node.geometry);
      for (const material of [].concat(node.material || [])) {
        resources.add(material);
        for (const value of Object.values(material)) if (value?.isTexture) resources.add(value);
      }
    });
    for (const resource of resources) resource.dispose();
  }

  const hasModel = anchor => anchor.kind === 'npc' && npcKey(anchor) !== 'narrator';

  async function create(T, logicalScene, parent, signal) {
    const [{ GLTFLoader }, { DRACOLoader }, skeleton] = await Promise.all([
      import('three/addons/loaders/GLTFLoader.js'),
      import('three/addons/loaders/DRACOLoader.js'),
      import('three/addons/utils/SkeletonUtils.js')
    ]);
    if (signal?.aborted) throw new DOMException('Aborted', 'AbortError');
    const lite = navigator.maxTouchPoints > 0 || innerWidth < 760;
    const usedProfiles = [...new Set(logicalScene.anchors.filter(hasModel).map(anchor => CHARACTER_PROFILES[npcKey(anchor)]).filter(profile => profile?.glbUrl))];
    // 手机端先试远景版本；加载失败时下面会回退到完整版
    const preferredUrl = profile => lite && profile.lodUrl ? profile.lodUrl : profile.glbUrl;
    const independentUrls = new Set(usedProfiles.map(preferredUrl));
    const weatheringReady = usedProfiles.some(profile => profile.weathering) && !M.characterWeathering
      ? import(new URL('character-weathering.js', SCRIPT_BASE).href).catch(error => console.warn('[人物做旧] 模块加载失败，跳过', error))
      : Promise.resolve();
    const loaded = new Map();
    const civilianUrls = new Set(logicalScene.streetModel && logicalScene.streetLife ? Object.values(CIVILIAN_PATHS) : []);
    const urls = new Set([...Object.values(paths), ...independentUrls, ...civilianUrls]);
    const draco = new DRACOLoader().setDecoderPath('/assets/webgpu40/vendor/three/jsm/libs/draco/gltf/');
    const results = await Promise.allSettled([...urls].map(async url => {
      try {
        const source = await loadModel(T, GLTFLoader, draco, url, signal);
        loaded.set(url, source);
      } catch (error) {
        if (signal?.aborted || !(independentUrls.has(url) || civilianUrls.has(url))) throw error;
        const full = usedProfiles.find(profile => profile.lodUrl === url && profile.glbUrl !== url)?.glbUrl;
        if (full) {
          console.info(`远景模型不可用，改用完整版：${full}`);
          try { loaded.set(full, await loadModel(T, GLTFLoader, draco, full, signal)); return; }
          catch (fullError) { if (signal?.aborted) throw fullError; console.warn(`独立人物模型回退：${full}`, fullError); return; }
        }
        console.warn(`独立人物模型回退：${url}`, error);
      }
    }));
    // 远景版本加载成功时，让 profile.glbUrl 的查找也能命中它
    for (const profile of usedProfiles) if (profile.lodUrl && loaded.has(profile.lodUrl) && !loaded.has(profile.glbUrl)) loaded.set(profile.glbUrl, loaded.get(profile.lodUrl));
    await weatheringReady;
    if (M.characterWeathering) for (const profile of usedProfiles) {
      const source = profile.weathering && loaded.get(profile.glbUrl);
      if (!source || source.userData?.czWeathered) continue;
      try { M.characterWeathering.apply(T, source.scene, profile.weathering); (source.userData ||= {}).czWeathered = true; }
      catch (error) { console.warn('[人物做旧] 应用失败，保持原样', error); }
    }
    draco.dispose();
    const failure = results.find(result => result.status === 'rejected');
    if (failure || signal?.aborted) {
      disposeModels(new Set(loaded.values()));
      throw failure?.reason ?? new DOMException('Aborted', 'AbortError');
    }

    const actors = [];
    const npcActors = new Map();
    const frustum = new T.Frustum(), projection = new T.Matrix4(), bounds = new T.Sphere(new T.Vector3(), 3);
    let playerActor = null;
    let dialogueAnchorId = null;
    function focusDialogue(event) {
      const { sceneId, anchorId } = event.detail || {};
      if (sceneId === logicalScene.sceneId) dialogueAnchorId = anchorId;
    }
    window.addEventListener('czmarch:interact', focusDialogue);

    function makeActor(role, height, profile = {}, style = {}, anchor) {
      const independent = loaded.get(profile.glbUrl);
      const civilian = !independent && CIVILIAN_PATHS[role] && loaded.has(CIVILIAN_PATHS[role]);
      const source = independent || loaded.get(civilian ? CIVILIAN_PATHS[role] : paths[role]);
      const materials = new Map();
      function tint(material) {
        const color = material.name === 'skin' ? style.skin : style.coat;
        if (independent || !color || !material.color) return material;
        if (civilian && material.name !== 'CIV coat') return material;   // 平民模型只换外衣颜色，头巾、头发、鞋不动
        if (!materials.has(material)) {
          const variant = material.clone();
          variant.color.lerp(new T.Color(color), material.name === 'skin' ? .25 : style.mix ?? .25);
          materials.set(material, variant);
        }
        return materials.get(material);
      }
      const model = skeleton.clone(source.scene);
      // Use posed vertices for independent rigs whose armature bounds include their bind pose.
      if (independent) model.updateMatrixWorld(true);
      const bounds = new T.Box3().setFromObject(model, Boolean(independent));
      const size = bounds.getSize(new T.Vector3());
      const center = bounds.getCenter(new T.Vector3());
      const scale = height * (profile.scaleBias ?? 1) / Math.max(size.y, 0.01);
      model.scale.setScalar(scale);
      model.position.set(-center.x * scale, -bounds.min.y * scale, -center.z * scale);
      model.traverse(node => {
        if (!node.isMesh) return;
        if (node.material) node.material = Array.isArray(node.material) ? node.material.map(tint) : tint(node.material);
        node.castShadow = true;
        node.receiveShadow = true;
        node.frustumCulled = false;
      });
      const root = new T.Group();
      root.name = 'march-actor-' + role;
      if (anchor) {
        root.userData.anchorId = anchor.anchorId;
        root.userData.modelUrl = independent ? profile.glbUrl : civilian ? CIVILIAN_PATHS[role] : paths[role];
      }
      root.add(model);
      parent.add(root);
      const mixer = new T.AnimationMixer(model);
      const actions = new Map();
      for (const clip of source.animations || []) actions.set(clip.name, mixer.clipAction(clip));
      // 有表情形态（browDown / smile 等）的网格：头、眉毛、胡茬。交谈时由 updateExpression 驱动
      const faces = [];
      model.traverse(node => { if (node.morphTargetDictionary && ['browDownLeft', 'browUpLeft', 'smile'].some(name => name in node.morphTargetDictionary)) faces.push(node); });
      const actor = { root, model, mixer, actions, current: null, role, materials, idle: profile.idle || 'Idle', faces, exprTime: Math.random() * 10 };
      play(actor, actor.idle);
      actors.push(actor);
      return actor;
    }

    function setMorph(actor, name, value) {
      for (const node of actor.faces) {
        const index = node.morphTargetDictionary[name];
        if (index !== undefined) node.morphTargetInfluences[index] = value;
      }
    }
    // 交谈时眉头时紧时松，偶尔一侧挑眉；待机时偶尔露一点笑意。必须在 mixer.update 之后调用，否则会被动画轨覆盖
    function updateExpression(actor, dt, talking) {
      if (!actor.faces.length) return;
      const t = actor.exprTime += dt;
      const knit = talking ? .22 + .2 * Math.max(0, Math.sin(t * 1.25)) * Math.max(0, Math.sin(t * .37 + 1)) : .08;
      const raise = talking ? .3 * Math.max(0, Math.sin(t * .9 + 2)) ** 6 : 0;
      const smile = talking ? .08 * Math.max(0, Math.sin(t * .5)) : .18 * Math.max(0, Math.sin(t * .21)) ** 8;
      setMorph(actor, 'browDownLeft', knit); setMorph(actor, 'browDownRight', knit * .92);
      setMorph(actor, 'browUpLeft', raise); setMorph(actor, 'browUpRight', 0);
      setMorph(actor, 'smile', smile);
    }

    function play(actor, name) {
      const next = actor.actions.get(name) || actor.actions.get(actor.idle) || actor.actions.values().next().value;
      if (!next || actor.current === next) return;
      actor.current?.fadeOut(0.16);
      next.reset().fadeIn(0.16).play();
      actor.current = next;
    }

    function place(actor, x, y, facing, surfaceHeight) {
      actor.root.position.set(x - logicalScene.world.w / 2, surfaceHeight(x, y), y - logicalScene.world.h / 2);
      if (Number.isFinite(facing)) actor.root.rotation.y = Math.atan2(Math.cos(facing), Math.sin(facing));
    }

    function disposeActor(actor) {
      actor.mixer.stopAllAction();
      actor.mixer.uncacheRoot(actor.model);
      const skeletons = new Set();
      actor.model.traverse(node => { if (node.isSkinnedMesh) skeletons.add(node.skeleton); });
      for (const skeleton of skeletons) skeleton.dispose();
      for (const material of actor.materials.values()) material.dispose();
      parent.remove(actor.root);
    }

    function ensurePlayer(role) {
      role = paths[role] ? role : 'soldier';
      if (playerActor?.role === role) return;
      if (playerActor) {
        disposeActor(playerActor);
        actors.splice(actors.indexOf(playerActor), 1);
      }
      playerActor = makeActor(role, 1.8);
    }

    // ---- 街市行人与摊主：只在街景章节、配置了 streetLife 时出现；不是剧情 NPC，不能交互 ----
    const life = logicalScene.streetModel && logicalScene.streetLife;
    // lite：见上方加载段落（手机端或窄屏）
    // 外衣换成百姓常见的靛蓝、褐、灰、本白粗布色；mix 越大换色越明显（平民模型只换外衣，通用模型整套换）
    const TINTS = { indigo: { coat: '#2f3f58', mix: .62 }, brown: { coat: '#6a4c34', mix: .58 }, grey: { coat: '#6d6e69', mix: .55 }, undyed: { coat: '#a89a7c', mix: .5 } };
    const STALL_DIRS = { s: [0, 1], n: [0, -1], e: [1, 0], w: [-1, 0] };
    const walkers = [], vendors = [];
    let lifeReady = false;
    const wrap = angle => Math.atan2(Math.sin(angle), Math.cos(angle));
    function routeAt(w, s) {
      let i = 0;
      while (i < w.lengths.length - 1 && s > w.lengths[i]) { s -= w.lengths[i]; i++; }
      const [ax, ay] = w.route[i], [bx, by] = w.route[(i + 1) % w.route.length], length = w.lengths[i] || 1, t = Math.min(1, Math.max(0, s / length));
      return { x: ax + (bx - ax) * t, y: ay + (by - ay) * t, tx: (bx - ax) / length, ty: (by - ay) / length };
    }
    // 平民模型没加载成功时退回通用模型；未知角色返回 null
    const streetRole = role => CIVILIAN_PATHS[role] ? (loaded.has(CIVILIAN_PATHS[role]) ? role : FALLBACK_ROLE[role]) : paths[role] ? role : null;
    const streetHeight = (role, r) => { const [lo, hi] = CIVILIAN_HEIGHT[role] || [1.62, 1.74]; return lo + (hi - lo) * r; };
    function spawnStreetLife() {
      lifeReady = true;
      if (!life) return;
      let seed = 3035;
      const rnd = () => { seed = (seed * 1664525 + 1013904223) >>> 0; return seed / 4294967296; };
      const list = (life.walkers || []).slice(0, lite ? 4 : 8);
      list.forEach((config, index) => {
        const role = streetRole(config.role);
        if (!config.route || config.route.length < 2 || !role) return;
        const route = config.route;
        const lengths = [];
        const count = config.loop ? route.length : route.length - 1;
        for (let i = 0; i < count; i++) { const [ax, ay] = route[i], [bx, by] = route[(i + 1) % route.length]; lengths.push(Math.hypot(bx - ax, by - ay)); }
        const total = lengths.reduce((sum, value) => sum + value, 0);
        const actor = makeActor(role, streetHeight(role, rnd()), {}, TINTS[config.tint] || {});
        actor.root.name = 'march-street-walker-' + index;
        const w = { index, actor, route, lengths, total, loop: !!config.loop, speed: config.speed || 1.2, s: (config.phase || 0) * total, dir: 1, wait: rnd() * 1.5, facing: 0 };
        const start = routeAt(w, w.s);
        w.facing = Math.atan2(start.ty, start.tx);
        walkers.push(w);
      });
      for (const stall of (life.stalls || []).slice(0, lite ? 4 : 12)) {
        const look = life.vendors?.[stall.kind];
        const role = look && streetRole(look.role);
        if (!role) continue;
        const f = STALL_DIRS[stall.face] || STALL_DIRS.s, r = [f[1], -f[0]], lx = (stall.vendor || 1) * (stall.w / 2 + .42);
        const actor = makeActor(role, streetHeight(role, rnd()), {}, TINTS[look.tint] || {});
        actor.root.name = 'march-street-vendor-' + stall.kind;
        vendors.push({ actor, x: stall.x + r[0] * lx - f[0] * .05, y: stall.y + r[1] * lx - f[1] * .05, home: Math.atan2(f[1], f[0]), facing: Math.atan2(f[1], f[0]) });
      }
    }
    function visibleNear(actor, x, y, player, surfaceHeight) {
      bounds.center.set(x - logicalScene.world.w / 2, surfaceHeight(x, y) + 1, y - logicalScene.world.h / 2);
      return Math.hypot(x - player.x, y - player.y) < (lite ? 38 : 55) && frustum.intersectsSphere(bounds);
    }
    function updateStreetLife(dt, player, surfaceHeight) {
      for (const w of walkers) {
        const here = routeAt(w, w.s);
        const hx = here.tx * w.dir, hy = here.ty * w.dir;
        const ahead = (ox, oy, radius) => { const dx = ox - here.x, dy = oy - here.y, d = Math.hypot(dx, dy); return d < radius && dx * hx + dy * hy > d * .3; };
        // 玩家挡在前面就停下看着玩家；两人迎面时编号大的让路
        const yieldPlayer = ahead(player.x, player.y, 1.9);
        const yieldWalker = !yieldPlayer && walkers.some(other => {
          if (other.index >= w.index) return false;
          const o = routeAt(other, other.s);
          return ahead(o.x, o.y, 1.15);
        });
        if (w.wait > 0) w.wait -= dt;
        else if (!yieldPlayer && !yieldWalker) {
          w.s += w.dir * w.speed * dt;
          if (w.loop) w.s = ((w.s % w.total) + w.total) % w.total;
          else if (w.s >= w.total || w.s <= 0) { w.s = Math.min(w.total, Math.max(0, w.s)); w.dir *= -1; w.wait = 1.4 + ((w.index * 7919) % 17) / 10; }
        }
        const moving = w.wait <= 0 && !yieldPlayer && !yieldWalker;
        const p = routeAt(w, w.s);
        const goal = yieldPlayer ? Math.atan2(player.y - p.y, player.x - p.x) : Math.atan2(p.ty * w.dir, p.tx * w.dir);
        w.facing += wrap(goal - w.facing) * (1 - Math.exp(-6 * dt));
        const visible = visibleNear(w.actor, p.x, p.y, player, surfaceHeight);
        w.actor.root.visible = visible;
        if (!visible) continue;
        place(w.actor, p.x, p.y, w.facing, surfaceHeight);
        play(w.actor, moving ? 'Walk' : w.actor.idle);
        if (w.actor.current) w.actor.current.timeScale = moving ? Math.min(1.25, Math.max(.75, w.speed / 1.3)) : 1;
      }
      for (const v of vendors) {
        const visible = visibleNear(v.actor, v.x, v.y, player, surfaceHeight);
        v.actor.root.visible = visible;
        if (!visible) continue;
        const near = Math.hypot(player.x - v.x, player.y - v.y) < 4.5;
        const goal = near ? Math.atan2(player.y - v.y, player.x - v.x) : v.home;
        v.facing += wrap(goal - v.facing) * (1 - Math.exp(-4 * dt));
        place(v.actor, v.x, v.y, v.facing, surfaceHeight);
      }
    }

    // ---- 走动的剧情人物（profile.roam）----
    // 以前每个站位各摆一个模型：同一章王贵有几个站位，场上就同时站着几个王贵。改为每个角色只有一个模型，
    // 站在「当前站位」：正在对话的站位 > 序号最小的未完成站位 > 最后完成的站位。剧情推进、当前站位换了，
    // 他就沿行走网格自己走过去；玩家跑远时，在玩家看不到的地方赶到离终点约 10m 处，再走进画面。
    // 没有 Walk 动画（旧版模型）时不走路，直接换到新站位，不会出现滑步。
    // 站位的交互范围、提示标签仍按锚点坐标算，与 B 方协议无关；人在站位时位置与原来完全一致。
    // 调试：控制台 CZMarchWorld._.actors3d.roamers 查看当前站位、模式、剩余路程
    const roamGrid = (() => {
      try {
        if (!M.path?.buildGrid) return null;
        return M.path.buildGrid(logicalScene.streetModel ? { ...logicalScene, blocked: [...(logicalScene.blocked || []), ...(logicalScene.streetBlocked || [])] } : logicalScene);
      } catch (error) { console.warn('[剧情人物走动] 行走网格生成失败，改为直接换位', error); return null; }
    })();
    const roamers = new Map();   // npcKey -> 状态
    const isRoaming = anchor => hasModel(anchor) && !!CHARACTER_PROFILES[npcKey(anchor)]?.roam;
    const storyOrder = anchor => { const m = /dialogue-\d+-(\d+)-/.exec(anchor.anchorId); return m ? Number(m[1]) : 99; };
    const wrapYaw = angle => Math.atan2(Math.sin(angle), Math.cos(angle));
    function currentStation(list) {
      const talking = list.find(anchor => anchor.anchorId === dialogueAnchorId);
      if (talking) return talking;
      const sorted = [...list].sort((x, y) => storyOrder(x) - storyOrder(y));
      return sorted.find(anchor => anchor.enabled && !anchor.completed) || sorted.filter(anchor => anchor.completed).at(-1) || null;
    }
    function planRoute(r, x, y) {
      const raw = roamGrid ? M.path.findPath(roamGrid, r.x, r.y, x, y) : null;
      const points = [{ x: r.x, y: r.y }, ...(raw || []).slice(1).map(point => ({ x: point.x, y: point.y }))];
      const last = points.at(-1);
      if (Math.hypot(last.x - x, last.y - y) > .05) points.push({ x, y });   // 网格格心到锚点精确坐标的最后一段
      r.path = points; r.seg = 0; r.segT = 0;
      r.remaining = points.slice(1).reduce((sum, point, i) => sum + Math.hypot(point.x - points[i].x, point.y - points[i].y), 0);
    }
    function advanceAlong(r, distance) {
      while (distance > 0 && r.seg < r.path.length - 1) {
        const s0 = r.path[r.seg], s1 = r.path[r.seg + 1], len = Math.hypot(s1.x - s0.x, s1.y - s0.y);
        if (len < 1e-6) { r.seg++; r.segT = 0; continue; }
        const left = len * (1 - r.segT);
        if (distance >= left) { distance -= left; r.remaining -= left; r.seg++; r.segT = 0; }
        else { r.segT += distance / len; r.remaining -= distance; distance = 0; }
      }
    }
    function spawnRoamer(key, station, surfaceHeight) {
      const profile = CHARACTER_PROFILES[key], style = M.anchors.NPC_STYLES[key] || {};
      const actor = makeActor(style.role || 'soldier', profile.height ?? DEFAULT_HEIGHT, profile, style, station);
      actor.root.name = 'march-roamer-' + key;
      const facing = station.facing ?? logicalScene.npcFacing ?? logicalScene.spawn?.facing;
      const heading = Number.isFinite(facing) ? facing : headings[facing] ?? Math.PI / 2;
      actor.initialYaw = Math.atan2(Math.cos(heading), Math.sin(heading));
      actor.root.rotation.y = actor.initialYaw;
      npcActors.set('roam:' + key, actor);
      const r = { key, actor, cfg: profile.roam, station, x: station.x, y: station.y, path: null, seg: 0, segT: 0, remaining: 0,
        mode: 'idle', wait: 2 + Math.random() * 4, heading: actor.initialYaw, canWalk: actor.actions.has('Walk') };
      if (!r.canWalk) console.info(`[剧情人物走动] ${key} 的模型没有 Walk 动画，换站位时直接换位`);
      place(actor, r.x, r.y, undefined, surfaceHeight);
      roamers.set(key, r);
      return r;
    }
    // 踱步：在站位 1.2~pace 米内找一个直线可达的点，走过去、站一会儿、再走回来
    function pickPaceTarget(r) {
      if (!roamGrid) return null;
      for (let tries = 0; tries < 8; tries++) {
        const angle = Math.random() * Math.PI * 2, d = 1.2 + Math.random() * (r.cfg.pace - 1.2);
        const x = r.station.x + Math.cos(angle) * d, y = r.station.y + Math.sin(angle) * d;
        let clear = true;
        for (let k = 1; k <= 6 && clear; k++) clear = M.path.walkableAt(roamGrid, r.station.x + (x - r.station.x) * k / 6, r.station.y + (y - r.station.y) * k / 6, .45);
        if (clear) return { x, y };
      }
      return null;
    }
    function updateRoamers(dt, player, anchors, surfaceHeight) {
      const groups = new Map();
      for (const anchor of anchors) if (isRoaming(anchor) && (anchor.enabled || anchor.completed)) {
        const key = npcKey(anchor);
        if (!groups.has(key)) groups.set(key, []);
        groups.get(key).push(anchor);
      }
      for (const [key, r] of roamers) if (!groups.has(key)) r.actor.root.visible = false;
      for (const [key, list] of groups) {
        const station = currentStation(list);
        let r = roamers.get(key);
        if (!station) { if (r) r.actor.root.visible = false; continue; }
        if (!r) r = spawnRoamer(key, station, surfaceHeight);
        const toPlayer = Math.hypot(player.x - station.x, player.y - station.y);
        const engaged = station.near || station.anchorId === dialogueAnchorId;
        const playerClose = engaged || toPlayer <= r.cfg.paceAway;
        // 1) 站位换了：走过去（不会走路就直接换位）
        if (station !== r.station) {
          r.station = station;
          if (!r.canWalk) { r.x = station.x; r.y = station.y; r.path = null; r.mode = 'idle'; }
          else { planRoute(r, station.x, station.y); r.mode = 'travel'; }
        }
        // 2) 等人时踱步；玩家走近、或正在对话时回到站位
        const away = Math.hypot(r.x - station.x, r.y - station.y);
        if (r.mode === 'idle' && r.canWalk && r.cfg.pace > 0 && !playerClose) {
          r.wait -= dt;
          if (r.wait <= 0) {
            const target = away < .3 ? pickPaceTarget(r) : { x: station.x, y: station.y };
            if (target) { planRoute(r, target.x, target.y); r.mode = away < .3 ? 'pace' : 'return'; }
            r.wait = 4 + Math.random() * 6;
          }
        }
        if (r.mode === 'linger') { r.wait -= dt; if (r.wait <= 0 || playerClose) { planRoute(r, station.x, station.y); r.mode = 'return'; } }
        if ((r.mode === 'pace' || r.mode === 'idle') && away > .3 && playerClose && r.canWalk) { planRoute(r, station.x, station.y); r.mode = 'return'; }
        // 3) 沿路线移动
        let moving = false, speed = 0;
        if (r.path && (r.mode === 'travel' || r.mode === 'pace' || r.mode === 'return')) {
          // 玩家跑远了：在看不见的地方赶路，只留最后约 10m 走进画面
          if (r.mode === 'travel' && !r.actor.root.visible && r.remaining > 14) advanceAlong(r, r.remaining - 10);
          const hurry = r.mode === 'travel' && r.remaining > 20;
          speed = (hurry ? r.cfg.hurrySpeed : r.cfg.speed) * (r.mode === 'pace' ? .7 : 1);
          const a0 = r.path[r.seg], b0 = r.path[Math.min(r.seg + 1, r.path.length - 1)];
          const hx = b0.x - a0.x, hy = b0.y - a0.y, hl = Math.hypot(hx, hy) || 1;
          const px = player.x - r.x, py = player.y - r.y, pd = Math.hypot(px, py);
          const blocked = pd < 1.3 && (px * hx + py * hy) / hl > pd * .3;   // 玩家挡在前面就停下
          if (!blocked) { advanceAlong(r, speed * dt); moving = true; }
          const s0 = r.path[r.seg], s1 = r.path[Math.min(r.seg + 1, r.path.length - 1)];
          r.x = s0.x + (s1.x - s0.x) * r.segT; r.y = s0.y + (s1.y - s0.y) * r.segT;
          if (s1.x !== s0.x || s1.y !== s0.y) r.heading = Math.atan2(s1.x - s0.x, s1.y - s0.y);
          if (r.seg >= r.path.length - 1) {
            const last = r.path.at(-1);
            r.x = last.x; r.y = last.y; r.path = null; moving = false;
            r.mode = r.mode === 'pace' ? 'linger' : 'idle';
            r.wait = r.mode === 'linger' ? 2 + Math.random() * 3 : 4 + Math.random() * 5;
          }
        }
        // 4) 显示、朝向、动画
        bounds.center.set(r.x - logicalScene.world.w / 2, surfaceHeight(r.x, r.y) + 1, r.y - logicalScene.world.h / 2);
        const range = logicalScene.streetModel ? Math.max(40, logicalScene.streetModel.actorRange ?? 18) : 80;
        const visible = Math.hypot(player.x - r.x, player.y - r.y) < range && frustum.intersectsSphere(bounds);
        r.actor.root.visible = visible;
        place(r.actor, r.x, r.y, undefined, surfaceHeight);
        const dx = player.x - r.x, dz = player.y - r.y, toMe = Math.hypot(dx, dz);
        const yaw = moving ? r.heading : toMe > .01 && (engaged || toMe < 6) ? Math.atan2(dx, dz) : r.mode === 'linger' ? r.heading : r.actor.initialYaw;
        r.actor.root.rotation.y += wrapYaw(yaw - r.actor.root.rotation.y) * (1 - Math.exp(-(moving ? 7 : 5) * dt));
        play(r.actor, moving ? 'Walk' : engaged ? 'Talk' : r.actor.idle);
        if (r.actor.current) r.actor.current.timeScale = moving ? Math.min(1.7, Math.max(.7, speed / 1.35)) : 1;
      }
      M.actors3d.roamers = [...roamers.values()].map(r => ({ key: r.key, station: r.station?.anchorId, x: +r.x.toFixed(2), y: +r.y.toFixed(2), mode: r.mode, remaining: +(r.remaining || 0).toFixed(1), visible: r.actor.root.visible }));
    }

    function visibleAnchor(anchor, anchors) {
      if (!anchor.enabled && !anchor.completed) return false;
      return !anchors.some(other => {
        if (other === anchor || !hasModel(other) || (!other.enabled && !other.completed)) return false;
        const preferred = Number(other.near) - Number(anchor.near);
        return Math.hypot(other.x - anchor.x, other.y - anchor.y) < 1.5 &&
          (preferred > 0 || (preferred === 0 && anchors.indexOf(other) < anchors.indexOf(anchor)));
      });
    }

    return {
      ensurePlayer,
      update(dt, player, anchors, camera, surfaceHeight) {
        projection.multiplyMatrices(camera.projectionMatrix, camera.matrixWorldInverse);
        frustum.setFromProjectionMatrix(projection);
        if (player.moving) dialogueAnchorId = null;
        ensurePlayer(player.roleId);
        place(playerActor, player.x, player.y, player.facing, surfaceHeight);
        playerActor.root.position.y += player.jumpHeight;
        play(playerActor, player.airborne && playerActor.actions.has('Jump') ? 'Jump' :
          player.running && playerActor.actions.has('Run') ? 'Run' : player.moving ? 'Walk' : 'Idle');
        if (playerActor.current) playerActor.current.timeScale = player.backing ? -.8 :
          player.running && !playerActor.actions.has('Run') ? 1.6 : 1;
        const localActors = new Map();
        if (logicalScene.streetModel) {
          for (const anchor of anchors) {
            if (!hasModel(anchor) || isRoaming(anchor) || !visibleAnchor(anchor, anchors)) continue;
            const distance = Math.hypot(anchor.x - player.x, anchor.y - player.y);
            const score = distance - (anchor.anchorId === dialogueAnchorId ? 100 : 0);
            const key = npcKey(anchor);
            if (distance < (logicalScene.streetModel.actorRange ?? 18) && score < (localActors.get(key)?.score ?? Infinity)) localActors.set(key, { anchor, score });
          }
        }
        updateRoamers(dt, player, anchors, surfaceHeight);
        for (const anchor of anchors) {
          if (!hasModel(anchor) || isRoaming(anchor)) continue;
          bounds.center.set(anchor.x - logicalScene.world.w / 2, surfaceHeight(anchor.x, anchor.y) + 1, anchor.y - logicalScene.world.h / 2);
          const nearby = !logicalScene.streetModel || localActors.get(npcKey(anchor))?.anchor === anchor;
          const visible = nearby && visibleAnchor(anchor, anchors) && frustum.intersectsSphere(bounds);
          let actor = npcActors.get(anchor.anchorId);
          if (!visible) { if (actor) actor.root.visible = false; continue; }
          if (!actor) {
            const key = npcKey(anchor);
            const profile = CHARACTER_PROFILES[key] || {};
            const style = M.anchors.NPC_STYLES[key] || {};
            actor = makeActor(style.role || 'soldier', profile.height ?? DEFAULT_HEIGHT, profile, style, anchor);
            const facing = anchor.facing ?? logicalScene.npcFacing ?? logicalScene.spawn?.facing;
            const heading = Number.isFinite(facing) ? facing : headings[facing] ?? Math.PI / 2;
            actor.initialYaw = Math.atan2(Math.cos(heading), Math.sin(heading));
            actor.root.rotation.y = actor.initialYaw;
            npcActors.set(anchor.anchorId, actor);
          }
          actor.root.visible = true;
          place(actor, anchor.x, anchor.y, undefined, surfaceHeight);
          const dx = player.x - anchor.x, dz = player.y - anchor.y;
          const distance = Math.hypot(dx, dz);
          const engaged = anchor.near || anchor.anchorId === dialogueAnchorId;
          const yaw = distance > .01 && (engaged || distance < 6) ? Math.atan2(dx, dz) : actor.initialYaw;
          const delta = yaw - actor.root.rotation.y;
          actor.root.rotation.y += Math.atan2(Math.sin(delta), Math.cos(delta)) * (1 - Math.exp(-8 * dt));
          play(actor, engaged ? 'Talk' : actor.idle);
        }
        if (!lifeReady) spawnStreetLife();
        updateStreetLife(dt, player, surfaceHeight);
        for (const actor of actors) if (actor.root.visible) actor.mixer.update(dt);
        for (const actor of npcActors.values()) if (actor.root.visible) updateExpression(actor, dt, actor.current === actor.actions.get('Talk'));
      },
      dispose() {
        window.removeEventListener('czmarch:interact', focusDialogue);
        for (const actor of actors) disposeActor(actor);
        actors.length = 0;
        walkers.length = 0;
        vendors.length = 0;
        roamers.clear();
        npcActors.clear();
        disposeModels(new Set(loaded.values()));
        loaded.clear();
        playerActor = null;
      }
    };
  }

  M.actors3d = { create };
})();
