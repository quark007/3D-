﻿# 把 Quick 的改动推到新分支，并开 PR。由同目录的「推送到新分支.bat」调用，也可以在 PowerShell 里直接运行。
# 安全检查：工作区必须干净；GitHub 的 main 上这些文件必须还是 Quick 改之前的版本，否则停下，不覆盖别人的改动。
param([string]$Branch = 'feat/quick-zunyi-life', [switch]$NoPush)
# 用 Continue：Windows PowerShell 5.1 会把 git/gh 正常写到 stderr 的提示当成错误中断；每条命令都单独检查退出码
$ErrorActionPreference = 'Continue'
try { [Console]::OutputEncoding = [Text.Encoding]::UTF8 } catch {}
$Patch = Split-Path -Parent $MyInvocation.MyCommand.Path
$Repo = Split-Path -Parent $Patch
function Fail($msg) { Write-Host "`n✗ $msg" -ForegroundColor Red; Write-Host '（没有做任何提交或推送）' -ForegroundColor DarkGray; exit 1 }
function Step($msg) { Write-Host "`n▶ $msg" -ForegroundColor Cyan }
function Ok($msg) { Write-Host "  ✓ $msg" -ForegroundColor Green }
function Git { & git @args; if ($LASTEXITCODE -ne 0) { Fail "git $($args -join ' ') 失败（退出码 $LASTEXITCODE）" } }

Step '检查环境'
Set-Location $Repo -ErrorAction Stop
if (-not (Test-Path 'changzheng\march-world\engine\renderer3d.js') -or -not (Test-Path '.git')) {
  Fail "这里不是 3D- 仓库根目录：$Repo`n  请把 quick-patch 文件夹整个放到仓库根目录（和 serve.cjs、changzheng 同一层）再运行。"
}
if (-not (Get-Command git -ErrorAction SilentlyContinue)) { Fail '没找到 git，请先安装 Git for Windows' }
$hasNode = [bool](Get-Command node -ErrorAction SilentlyContinue)
if (-not (& git config user.name)) { Fail '还没设置 git 用户名：先运行 git config --global user.name "你的名字" 和 git config --global user.email "你的邮箱"' }
$exclude = '.git\info\exclude'
if (-not (Select-String -Path $exclude -Pattern '^quick-patch/$' -Quiet -ErrorAction SilentlyContinue)) { Add-Content -Path $exclude -Value 'quick-patch/' -Encoding ascii -ErrorAction Stop }
$dirty = & git status --porcelain --untracked-files=no
if ($dirty) { Fail "工作区有未提交的改动，先提交或运行 git stash：`n$($dirty -join "`n")" }
$prev = (& git rev-parse --abbrev-ref HEAD).Trim()
Ok "仓库 $Repo，当前分支 $prev"

Step '获取 GitHub 上最新的 main'
Git fetch origin main
& git rev-parse --verify --quiet "refs/heads/$Branch" *> $null
if ($LASTEXITCODE -eq 0) { Fail "本地已经有分支 $Branch。如果是上次跑了一半，先运行：git switch $prev ; git branch -D $Branch" }
if (& git ls-remote --heads origin $Branch) { Fail "GitHub 上已经有分支 $Branch，可能之前推送过了。要换个名字可以运行：.\push-quick-branch.ps1 -Branch feat/quick-zunyi-life-2" }

Step '确认 main 上的这些文件还是 Quick 改之前的版本'
$expected = @{
  'changzheng/march-world/engine/renderer3d.js' = '03965b1ba68bb7d87e3998b12d97ee6c2c65ddda'
  'changzheng/march-world/engine/actors3d.js' = 'f6696c2016fd043e3d0c1ad89af90f73a88bd132'
  'changzheng/march-world/engine/character-preview.js' = 'c522f57bd25194842ea053c6cef6bf11fe3fbce2'
  'changzheng/march-world/scenes/chapter-03.js' = 'd0b24a316c5d833f1f0cc52668d43743fec9cda2'
  'changzheng/assets/scenes/zunyi-realscan/zunyi_street.glb' = '8e55105680c74911d9df20298b5300bcb41e2049'
  'changzheng/assets/characters/wang-gui/wang-gui-web.glb' = 'c1b44155162ef4776742807b3c4bf87439b9a5be'
}
$changed = @()
foreach ($p in $expected.Keys) {
  $now = (& git rev-parse "origin/main:$p" 2>$null)
  if ($now -ne $expected[$p]) { $changed += "  $p（main 上现在是 $now，Quick 基于 $($expected[$p].Substring(0,7))）" }
}
if ($changed) { Fail "这些文件在 Quick 改完之后，GitHub 的 main 上又被人改过。直接覆盖会冲掉别人的改动，请把下面这几行发给 Quick：`n$($changed -join "`n")" }
Ok '6 个文件都对得上（main 基于 f537df4）'

Step '用 node 检查 JS 语法（第一次真正的语法检查）'
if ($hasNode) {
  $bad = @()
  foreach ($f in Get-ChildItem -Path "$Patch\files" -Recurse -Filter *.js) {
    $target = $f.FullName
    if ($f.Name -eq 'character-preview.js') { $target = Join-Path $env:TEMP 'quick-check-preview.mjs'; Copy-Item $f.FullName $target -Force -ErrorAction Stop }
    $out = & node --check $target 2>&1
    if ($LASTEXITCODE -ne 0) { $bad += "--- $($f.Name)`n$($out -join "`n")" } else { Ok $f.Name }
  }
  if ($bad) { Fail "语法检查没通过，请把下面的内容发给 Quick：`n$($bad -join "`n")" }
} else { Write-Host '  ! 没找到 node，跳过语法检查（强烈建议装 Node 18+ 再跑一次）' -ForegroundColor Yellow }

Step "从 origin/main 新建分支 $Branch 并复制文件"
Git checkout -b $Branch origin/main
Copy-Item -Path "$Patch\files\*" -Destination $Repo -Recurse -Force -ErrorAction Stop
Ok "已复制 $((Get-ChildItem "$Patch\files" -Recurse -File).Count) 个文件"

Step '分三次提交'
$groups = @(
  @{ msg = 'msg-1-assets.txt'; paths = @('changzheng/assets/scenes/zunyi-realscan/zunyi_street.glb', 'changzheng/assets/characters/civilians', 'changzheng/assets/characters/wang-gui/wang-gui-web.glb') },
  @{ msg = 'msg-2-code.txt'; paths = @('changzheng/march-world/engine', 'changzheng/march-world/scenes/chapter-03.js') },
  @{ msg = 'msg-3-tools.txt'; paths = @('tools/quick', 'evidence/quick') }
)
foreach ($g in $groups) {
  Git add -- @($g.paths)
  & git diff --cached --quiet
  if ($LASTEXITCODE -eq 0) { Write-Host "  - $($g.msg)：没有变化，跳过" -ForegroundColor DarkGray; continue }
  Git commit -q -F "$Patch\$($g.msg)"
  Ok ((& git log -1 --format='%h %s') -join '')
}
$left = & git status --porcelain --untracked-files=no
if ($left) { Write-Host "  ! 还有未提交的文件（不影响推送）：`n$($left -join "`n")" -ForegroundColor Yellow }

if ($NoPush) { Write-Host "`n已在本地提交，没有推送（-NoPush）。确认无误后运行：git push -u origin $Branch" -ForegroundColor Yellow; exit 0 }
Step '推送到 GitHub'
Git push -u origin $Branch
Ok "已推送 $Branch"

Step '开 PR'
$compare = "https://github.com/quark007/3D-/compare/main...$($Branch)?expand=1"
$opened = $false
if (Get-Command gh -ErrorAction SilentlyContinue) {
  & gh auth status *> $null
  if ($LASTEXITCODE -eq 0) {
    & gh pr create --repo quark007/3D- --base main --head $Branch --title 'feat(ch3,npc): 遵义街景氛围/相机/去重复/街市平民 + 王贵走动与做旧（未经浏览器测试）' --body-file "$Patch\PR说明.md"
    $opened = ($LASTEXITCODE -eq 0)
  }
}
if (-not $opened) {
  Write-Host "  没有可用的 gh 命令行，打开网页手动开 PR。PR 描述在 quick-patch\PR说明.md，复制粘贴即可：`n  $compare" -ForegroundColor Yellow
  Start-Process $compare
}
Write-Host "`n完成。现在你在 $Branch 分支上，回到原来的分支：git switch $prev" -ForegroundColor Green
