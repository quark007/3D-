@echo off
chcp 65001 >nul
rem 双击运行：把 Quick 的改动推到新分支 feat/quick-zunyi-life 并开 PR。quick-patch 文件夹要放在仓库根目录。
rem 只想先在本地提交、不推送：在这个文件夹里打开命令行，运行  推送到新分支.bat -NoPush
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0push-quick-branch.ps1" %*
echo.
pause
